<footer class="main-footer">
    <div class="footer-left">
        Copyright @<?php echo date('Y'); ?> <div class="bullet"></div> Developed By <a href="">Human</a>
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer>

</html>